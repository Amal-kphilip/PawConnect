# 🐾 PawConnect - Pet Adoption Portal

A comprehensive, clean, and beginner-friendly Pet Adoption Web Portal built with **procedural PHP**, **MySQLi with prepared statements**, **HTML5**, and **plain CSS3** (no external framework or Composer dependencies required). Designed to run seamlessly on standard **XAMPP / WAMP** local server environments.

---

## 📁 Project File Structure

```text
Pawconnect/
├── config/
│   └── db.php                     # Database connection & dynamic BASE_URL configuration
├── includes/
│   ├── auth.php                   # Authentication, CSRF, flash notifications & helpers
│   ├── header.php                 # Responsive navigation bar & flash alert container
│   └── footer.php                 # Portal footer & mobile navigation scripts
├── css/
│   └── style.css                  # Modern responsive CSS (Poppins font, warm theme)
├── uploads/
│   └── default.png                # Fallback pet placeholder graphic
├── shelter/
│   ├── dashboard.php              # Shelter metrics, recent applications, pet inventory
│   ├── add_pet.php                # Add pet form with file upload validation (JPG/PNG/WEBP)
│   ├── edit_pet.php               # Edit pet profile, adoption status & image
│   ├── delete_pet.php             # Delete pet action with image cleanup
│   ├── view_applications.php      # Review applications & approve/reject workflow
│   └── manage_visits.php          # Manage scheduled visits & update outcomes
├── admin/
│   └── dashboard.php              # Global metrics & management for users/shelters/pets
├── index.php                      # Homepage (Hero search, dynamic stats, featured pets)
├── register.php                   # Dual registration for Adopters & Shelter organizations
├── login.php                      # Secure login with session regeneration
├── logout.php                     # Clean session teardown
├── pets.php                       # Multi-filter search & pagination grid
├── pet_details.php                # Detailed pet specs, shelter card, adopt/visit actions
├── apply.php                      # Adoption application form with duplicate check
├── schedule_visit.php             # Visit booking (Sunday blackout & slot conflict check)
├── my_applications.php            # Adopter application tracker with status badges
├── my_visits.php                  # Adopter visit manager with visit cancellation
├── seed.php                       # 1-Click Database installer & demo data seeder
├── database.sql                   # Full SQL schema & complete dummy dataset
└── README.md                      # Project documentation & testing guide
```

---

## 🚀 Quick Setup Instructions (XAMPP / WAMP)

### Step 1: Copy Project Files
Place the `Pawconnect` folder into your web server root directory:
- **XAMPP (Windows):** `C:\xampp\htdocs\Pawconnect`
- **WAMP (Windows):** `C:\wamp64\www\Pawconnect`

### Step 2: Start Apache & MySQL
Open your **XAMPP / WAMP Control Panel** and ensure both **Apache** and **MySQL** services are running.

### Step 3: Initialize Database (Choose either Option A or B)

#### Option A (Recommended - 1-Click Setup):
Open your web browser and navigate to:
```text
http://localhost/Pawconnect/seed.php
```
*This automatically creates the `pet_adoption` database, configures all tables, and seeds full dummy records with secure hashed passwords.*

#### Option B (Manual phpMyAdmin Import):
1. Open `http://localhost/phpmyadmin`
2. Click on the **Import** tab
3. Choose the file `database.sql` from the project folder and click **Import** / **Go**

### Step 4: Launch PawConnect
Open your browser and visit:
```text
http://localhost/Pawconnect/
```

---

## 🔑 Demo Login Credentials

> **All demo accounts use the standard password:** `password123`

| Role | Account / Shelter | Email Address | Password |
| :--- | :--- | :--- | :--- |
| **Admin** | Master Administrator | `admin@pawconnect.com` | `password123` |
| **Shelter 1** | Happy Tails Shelter (Kochi) | `shelter1@happytails.org` | `password123` |
| **Shelter 2** | Safe Paws Rescue (Kannur) | `shelter2@safepaws.org` | `password123` |
| **Shelter 3** | Second Chance Animal Home (Kozhikode) | `shelter3@secondchance.org` | `password123` |
| **Adopter 1** | Anjali Nair | `anjali@gmail.com` | `password123` |
| **Adopter 2** | Rahul Menon | `rahul@gmail.com` | `password123` |
| **Adopter 3** | Fathima Rasheed | `fathima@gmail.com` | `password123` |
| **Adopter 4** | Arjun Das | `arjun@gmail.com` | `password123` |
| **Adopter 5** | Meera Krishnan | `meera@gmail.com` | `password123` |
| **Adopter 6** | Joseph Thomas | `joseph@gmail.com` | `password123` |

---

## 🧪 Comprehensive Feature Checklist to Test

### 1. Public / Adopter Features
- [x] **Home Page:** Dynamic live stats counters, species & city quick search, and 6 latest featured pets.
- [x] **Pet Search & Filter:** Filter pets by species, gender, size, age group, city, and status with pagination (9 pets per page).
- [x] **Pet Details Profile:** View pet specifications (size, age, breed, vaccination), shelter contact card, and similar pets.
- [x] **Submit Adoption Application:** Log in as an adopter (e.g. `anjali@gmail.com`), pick an available pet, and submit the application. Verified duplicate submission prevention.
- [x] **Schedule Shelter Visit:** Datepicker prevents booking past dates and blocks Sundays; slots prevent double-booking for the same pet.
- [x] **Adopter Dashboard:** View submitted applications with color-coded status badges; cancel upcoming visits in "My Visits".

### 2. Shelter Management Features
- [x] **Shelter Dashboard:** Real-time statistics on total pets, available pets, pending applications, and upcoming visits.
- [x] **Pet Inventory & Image Upload:** Add pets with JPG/PNG/WEBP validation (&le; 2MB) or image URLs. Edit details or delete records.
- [x] **Adoption Review Workflow:** Review applicant details. When an application is **Approved**, the pet is automatically marked as **Adopted**, and all other pending applications for that pet are automatically marked as **Rejected**.
- [x] **Visit Outcomes:** Update scheduled visits to **Completed** or **Cancelled**.

### 3. Administrator Features
- [x] **Global System Directory:** Master overview of all user accounts, verified shelters with pet tallies, and global pet listings.
- [x] **Account Management:** Delete user accounts with foreign key cascade protection for system integrity.

---

## 🛡️ Security & Technical Highlights
- **Prepared Statements:** 100% parameter binding across all dynamic queries to eliminate SQL Injection risks.
- **Password Security:** Native `password_hash()` and `password_verify()` with `session_regenerate_id()` on login.
- **CSRF Protection:** Cryptographic tokens generated per session and validated on state-changing POST requests.
- **XSS Prevention:** Context-aware `htmlspecialchars()` wrapping on all rendered variables.
- **Zero Dependencies:** Pure PHP 7.4+ / 8.x + MySQL + Plain CSS. No Composer, Node.js, or external CSS/JS libraries required.
